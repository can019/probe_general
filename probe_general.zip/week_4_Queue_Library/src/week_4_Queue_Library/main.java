package week_4_Queue_Library;
import java.util.LinkedList;
import java.util.Deque;
import java.util.PriorityQueue;
import java.util.ArrayDeque;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		Deque<Integer> sample1 = new LinkedList<Integer>();
		ArrayDeque<Integer> sample2 = new ArrayDeque<Integer>();
		
		
	}

}
